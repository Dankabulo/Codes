﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExportDataToExcel.Interfaces
{
    public interface IExportFilesToLocation
    {
        string GetFolderLocation();
    }
}
